#include <iostream>
#include <string>
#include <cstring>
#include <fstream>
#include <cstdlib>

#define STUDENTS_FILE_NAME "students.txt"
#define STUDENTS_SCORES_FILE_NAME "students_scores.txt"
#define STUDENTS_COMMENTS_FILE_NAME "students_comments.txt"

#define CLEAR_SCRREN_CODE "\x1B[2J\x1B[H"

using namespace std;

//structure for question an answer
typedef struct{

    string questionString;
    char correctAnswer;

}Question;

typedef struct{

    int id;
    string student_name;
    int level;
    string password;

}Student;

typedef struct{

    int student_id;
    string commentString;

}Comment;


void menu();
void getStudentDetails();
void registerStudent(const Student& student);
bool isStudentExist(const Student& student);
void examProtocol();
void showStudentMarks();
void showStudentComments();
void printStudentDetails();
void clearScreen();


class QuestionGenerator{
private: 
    Question questions[100];

public:

    QuestionGenerator(){

        Question question1 = {"what is the capital city of America?\na. Washington DC \nb. New York \nc. Florida \nd. Texas", 'a'};

        Question question2 = {"what is the capital city of China?\na. Shangai \nb. Beijing \nc. Fl \nd. Seoul", 'a'};
        
        Question question3 = {"what is the capital city of Ghana?\na. Kumasi\nb. Accra \nc. Cape Coast \nd. Tamale", 'b'};

        Question question4 = {"what is the capital city of Argentina?\na. Madeira \nb. Rio De Jainero \nc. London \nd. Buenos Aires", 'd'};

        Question question5 = {"what is the capital city of Portugal?\na. Lisbon \nb. Pueblo Nuevo \nc. Madrid \nd. None Of the above", 'a'};

        Question question6 = {"what is the capital city of Spain?\na. Madrid\nb. Barcelona \nc. Sevilla \nd. Grenada", 'a'};


        Question question7 = {"what is the capital city of Netherlands?\na. Holland \nb. Amsterdam \nc. The Carribean \nd. Rotterdam", 'b'};

        Question question8 = {"what is the capital city of Germany?\na. Munich \nb. Frankfurt \nc. Berlin \nd. Stuggart", 'c'};

        Question question9 = {"what is the capital city of South Africa?\na. Capetown \nb. Johannesburg \nc. Soweto \nd. Suncity", 'b'};

        Question question10 = {"what is the capital city of Brazil?\na.Washington DC \nb. Rio de Jainero \nc. Sao Paolo \nd. Santos", 'b'};

        Question question11 = {"what is the capital city of Senegal?\na.Port Novo \nb. Djibouti \nc. Florida \nd. None Of the above", 'd'};

        Question question12 = {"Who created C++?\na.Bjarne Stroustrup \nb. Dennis Ritchie \nc. Guido Van Rossum \nd. John Eich", 'a'};
        
        Question question13 = {"Who were the founders of Apple Inc.?\na. Bill Gates and Mark Zuckerburg\nb. Bill Gates and Steve Jobs \nc. Steve Jobs and Steve Wozniak\nd. Sundar Pichai and Steve Jobs", 'c'};

        Question question14 = {"what is the capital city of Saudi Arabia?\na. Mecca \nb. Riyadh \nc. Jedda \nd. Dubai",  'b'};

        Question question15 = {"what is the capital city of South Korea?\na.Seoul \nb. Busan \nc. Hong Kong \nd. Los Angeles", 'a'};

        Question question16 = {"How many parts make up a computer?\na. 1 \nb. 2 \nc. 3 \nd. 4", 'b'};

        Question question17 = {"Which of these people contributed to computing?\na. Otto Von-Neuwman\nb. Oprah \nc. Martin Luther King Jnr \nd. None of the above", 'a'};

        Question question18 = {"what is the capital city of Nigeria?\na. Abuja \nb. Lagos \nc. Anambra \nd. None of the above", 'a'};

        Question question19 = {"what is the capital city of Code D'Ivoire?\na.Yammousokro \nb. Abidjan \nc. Ouadugou \nd. Pretoria", 'a'};

        Question question20 = {"what is the capital city of Canada?\na.North Pole \nb. Orlando \nc. Philadelphia \nd. Toronto", 'd'};

        Question question21 = {"what is the capital city of Jamaica?\na. Kingston \nb. Kington \nc. Kinsting \nd. Kinstong", 'a'};

        Question question22 = {"what is the capital city of United Kingdom?\na. Manchester \nb. London \nc. Nottingham \nd. Swansea", 'b'};

        Question question23 = {"what is the other name for Britain?\na. United Kingdom \nb. Sweden \nc. Austrilia \nd. Ireland", 'a'};

        Question question24 = {"Who is the Paramount Chief of the Asante Kingdom in Ghana?\na.President Nana Addo Dankwah Akuffo Addo \nb. Otumfour Osei Tutu II \nc. Ga Mantse \nd. Nana Nkansah Boadu Ayeboafo", 'b'};

        Question question25 = {"what is the capital city of Burkina Faso?\na.Washington DC \nb. New York \nc. Florida \nd. Ouagadugou", 'd'};

        Question question26 = {"Who was the founder of Microsoft Corp?\na.Sundar Pichai \nb. Bill Gates \nc. Steve Jobs \nd. Jeff Bezos", 'b'};
        
        Question question27 = {"Pick the odd one out.\na.MySQL DC \nb. PostgreSQL \nc. Mongo DB \nd. Google Firebase",'d'};

        Question question28 = {"Pick the odd one out \na. Keyboard \nb. Microphone\nc. Monitor \nd. Scanner", 'c'};

        Question question29 = {"What is the best Team in the world?\na. Real Madrid \nb. Manchester City \nc. Bayern Munich \nd. Kumasi Asante Kotoko",  'a'};

        Question question30 = {"Python programming lanuguage was created by .......... \na. Dennis Ritchie \nb. Elon Musk \nc. Guido Van Rossum \nd. Bjarne Stroutrup",  'c'};


        Question question31 = {"All the following are programming languages execpt.......\na. HTML \nb. Javascript \nc. Java \nd. C++",  'a'};

        questions[0] = question1;
        questions[1] = question2;
        questions[2] = question3;
        questions[3] = question4;
        questions[4] = question5;
        questions[5] = question6;
        questions[6] = question7;
        questions[7] = question8;
        questions[8] = question9;
        questions[9] = question10;
        questions[10] = question11;
        questions[11] = question12;
        questions[12] = question13;
        questions[13] = question14;
        questions[14] = question15;
        questions[15] = question16;
        questions[16] = question17;
        questions[17] = question18;
        questions[18] = question19;
        questions[19] = question20;
        questions[20] = question21;
        questions[21] = question22;
        questions[22] = question23;
        questions[23] = question24;
        questions[24] = question25;
        questions[25] = question26;
        questions[26] = question27;
        questions[27] = question28;
        questions[28] = question29;
        questions[29] = question30;
        questions[30] = question31;
    
    }

    Question * generateFiveRandomQuestions(){

        Question* randomQuestions = new Question[5];

        int delimeter = 0;
        int counter = 0;

        cout << "Generating questions please wait ..."<<endl;

        while(delimeter != 100){

            delimeter++;

            int randomNumber = getRandomNumber(0, 29);

            Question currentQuestion = this->questions[randomNumber];

            bool hasFoundMatch = false;

            for(int i  = 0; i < 5; i++){

                Question question = randomQuestions[i];

                if(question.questionString == currentQuestion.questionString){
                    hasFoundMatch = true;
                    break;
                }

            }

            if(hasFoundMatch){
                continue;
            }

            randomQuestions[counter] = currentQuestion;

            if(counter == 4){
                cout << "Questions set and ready"<<endl;
                break;
            }

            counter++;

        }

        return randomQuestions;

    }

    int getRandomNumber(int min, int max) {
        return min + rand() % (max - min + 1);
    }


};


class OnlineExam{
private:
    Question* questions;
    Comment comment;
    Student student;
    int score = 0;
    char* scoringMap;


public: 

    OnlineExam(Student _student):student(_student){
       
        //code to load the question
        QuestionGenerator generator;
        this->questions = generator.generateFiveRandomQuestions();

        this->scoringMap = new char[5];

    }

    void commenceExamination(){

        clearScreen();

        for(int i = 0; i < 5; i++){

            Question question = this->questions[i];

            char userAnswer;

            cout << "Q" << i+1 << ":." << question.questionString << endl;
            cin >> userAnswer;

            if(userAnswer == question.correctAnswer){
                this->scoringMap[i] = 'c';
                score++;
            }else{
                this->scoringMap[i] = 'x';
            }
            

        }

        //get comment
        string commentString;

        cout << "Enter comment: ";
        cin >> commentString;

        Comment comment = {this->student.id, commentString};
        this->comment = comment;

        saveExamination();
        displayResult();

    }

    void displayResult(){

        cout << "EXAM RESULTS" << endl << endl;
        
        cout << "ID: " << this->student.id << endl;
        cout << "Student Name: " << this->student.student_name << endl;
        cout << "Level: " << this->student.level << endl; 

        cout << "Your Score is " << this->score << "/5."<<endl;
        cout << "Scoring Map\n" << "\t" << this->scoringMap << endl << endl;

        cout << "Scoring Map Key:\n\t" << "c -> correct Answer" << "\n\t x -> Incorrect answer" << endl << endl;

    }

    void saveExamination(){

        ofstream scoresFile(STUDENTS_SCORES_FILE_NAME);
        
        if(!scoresFile.is_open()){
            cout << "Could not open scores file, '"<<STUDENTS_SCORES_FILE_NAME <<"'"<<endl;
        }

        scoresFile << this->student.id << " -> " << this->score;

        scoresFile.close();
        cout << "Done Saving your Examination Scores!";

        if(this->comment.commentString != ""){
            saveComment();
        }

        cout << "Done saving your Examination!" << endl;
        menu();

    }

    void saveComment(){

        ofstream commentsFile(STUDENTS_COMMENTS_FILE_NAME);

        if(!commentsFile.is_open()){
            cout << "Could not open comments file, '" << STUDENTS_COMMENTS_FILE_NAME <<"'"<< endl;
        }

        int student_id = this->student.id;

        commentsFile << student_id << " -> "<< this->comment.commentString;
        commentsFile.close();

        cout << "Done Saving comments!" << endl;

    }

};


int main(){

    menu();
    //getStudentDetails();
    printStudentDetails();

    return 0;
}

void menu(){

    int choice;

    cout << "Online Examination System";
    cout << endl;
    cout << "1 - Register New Student" << endl;
    cout << "2 - Start Exam" << endl;
    cout << "3 - Show Students List" << endl;
    cout << "4 - Show Student Marks" << endl;
    cout << "5 - show Exam Comments " << endl;
    cout << "6 - End Online Examination System" << endl;

    cout << "Enter your choice: ";
    cin >> choice;

    switch(choice){
        case 1:
            getStudentDetails();
            break;

        case 2:
            examProtocol();
            break;
        
        case 3: 
            printStudentDetails();
            break;
        
        case 4: 
            showStudentMarks();
            break;

        case 5:
            showStudentComments();
            break;

        case 6:
            cout << "Exiting Online Examination System";
            break;

        default:
            cout << "Invalid choice entered ... Hence exiting application";
            break;
    } 

}

void examProtocol(){


    cout << endl << "START EXAMINATION" << endl << endl;
    
    int id;
    string student_name;
    int level;
    string password;

    cout << "Enter your id: ";
    cin >> id;

    cout << endl << "Enter your fullname: ";
    cin >> student_name;

    cout << endl << "Enter your level:";
    cin >> level;

    cout << endl << "Enter your password: ";
    cin >> password;

    Student student = {id, student_name, level, password};

    if(isStudentExist(student)){
        OnlineExam exam(student);
        exam.commenceExamination();
    }else{
        cout << "Student does not exist in the database\nPlease make sure you enter the correct detail \n" << endl;
        menu();
    }


}

void showStudentMarks(){

    cout << endl << "STUDENT MARKS" << endl << endl;

    //get the students file name
    ifstream studentsFile(STUDENTS_FILE_NAME);

    ifstream scoresFile(STUDENTS_SCORES_FILE_NAME);

    if(!(studentsFile.is_open() && scoresFile.is_open())){
        cout << "Could not open required database files";
        return;
    }

    int studentScoreID;
    string arrowString;
    int score;

    int i = 0;

    while(scoresFile >> studentScoreID >> arrowString >> score){

        i++;
        string outPutSentence = to_string(i) + ". ";
    
        //getting usermae
        int studentID;
        string studentName;
        int level;
        string password;

        while(studentsFile >> studentID >> studentName >> level >> password){
            if(studentID == studentScoreID){
                outPutSentence = outPutSentence + studentName + " - " + to_string(score) + "/5 Marks";
                break;
            }
        }

        cout << outPutSentence << endl;

    }

    studentsFile.close();
    scoresFile.close();

    cout << endl;
    cout << endl;

    menu();

}

void showStudentComments(){

    ifstream studentsFile(STUDENTS_FILE_NAME);
    ifstream commentsFile(STUDENTS_COMMENTS_FILE_NAME);

    if(!(studentsFile.is_open() && commentsFile.is_open())){
        cout << "Could not open required files" << endl;
        menu();
        return;
    }

    int studentCommentID;
    string arrowString;
    string commentString;

    int i = 0;

    while(commentsFile >> studentCommentID >> arrowString >> commentString){
        
        i++;
        string outputString = to_string(i) + ":. ";

        int studentID;
        string studentName;
        int level;
        string password;

        while(studentsFile >> studentID >> studentName >> level >> password){

            if(studentID == studentCommentID){
                outputString = outputString + studentName + "(id: " + to_string(studentID) + ",  level: " + to_string(level) + ") \n";
                break;
            }

        }

        outputString = outputString + "\t" + commentString;
        cout << outputString << endl << endl;

    }

    studentsFile.close();
    commentsFile.close();

    menu();

}

void getStudentDetails(){

    int id;
    string student_name;
    int level;
    string password;

    cout << "Register Student"<< endl;

    cout << "Student ID: ";
    cin >> id;

    cout << endl << "Student name: ";
    cin >> student_name;

    cout << endl << "Level: ";
    cin >> level;

    cout << endl << "Password: ";
    cin >> password;

    if(student_name == "" || level < 0 || password == ""){
        cout << "Required fields for user registration cannot be null";
        return;
    }

    Student student = {id, student_name, level, password};
    registerStudent(student);

}

//this function is to handle student registeration
void registerStudent(const Student& student){

    if (isStudentExist(student)) {
        cout << "Student already exists in the database. Please use a different password if you have the same credential." << endl;
        return;
    }

    ofstream studentsFile("students.txt", ios::app); // Open in append mode

    int id = student.id;
    string student_name = student.student_name;
    int level = student.level;
    string password = student.password;

    if (studentsFile.is_open()) {
        studentsFile << id << " " << student_name << " " << level << " " << password << endl; // Use << for writing
        cout << "Student registered successfully." << endl;
    }

    studentsFile.close();
    menu();
}

bool isStudentExist(const Student& student){

    int id = student.id;
    string student_name = student.student_name;
    int level = student.level;
    string password = student.password;

    ifstream studentsFile(STUDENTS_FILE_NAME);

    if(!studentsFile.is_open()) {
       cout << "Could not open students database file, 'students.txt' for reading" << endl;
       return false;
    } 

    int _id;
    string _studentName;
    int _level;
    string _password;

    while(studentsFile >> _id >> _studentName >> _level >> _password){

        cout << "Icomparison ID: " << _id << endl;

        if (_id == id && _studentName == student_name && _level == level && password == _password) {   
            return true;
        }

    }

    studentsFile.close();

    return false;
}

void printStudentDetails(){

    ifstream studentsFile(STUDENTS_FILE_NAME);

    if(!studentsFile.is_open()){
        cout << "Could not open students dataase file" << endl;
        return;
    }

    cout << "STUDENTS" << endl << endl;

    int i = 0;
    Student student;

   while(studentsFile >> student.id >> student.student_name >> student.level >> student.password){

        i++;

        cout << i << ":. "<<endl;
        cout << "Student ID: " << student.id << endl;
        cout << "Student Name: " << student.student_name << endl;
        cout << "Level: " << student.level << endl;
        cout << endl << endl; 

    }

    studentsFile.close();
    menu();
}

void clearScreen(){
    cout << CLEAR_SCRREN_CODE;
}